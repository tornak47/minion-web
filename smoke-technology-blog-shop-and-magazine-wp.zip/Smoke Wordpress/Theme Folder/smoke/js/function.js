$(window).load(function() { $('#slider').nivoSlider(); });
jQuery(function(){ jQuery('ul.menu').superfish(); });
$().ready(function() {
$('#coda-slider-1').codaSlider({
autoSlide:false,
autoSlideInterval: 4000,
autoSlideStopWhenClicked: true
});
});